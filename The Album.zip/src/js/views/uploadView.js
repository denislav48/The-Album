import {elements} from './base';


export const getForm = () => elements.uploadForm;
export const getCategory = () => elements.uploadFormSelect.value;
export const getUserName = () => elements.uploadFormUserName.value;
export const getTitle = () => elements.uploadFormTitle.value;
export const send = () => elements.uploadFormPost;
