
 export const elements = {
       searchCategory: document.querySelector('.select'),
       uploadForm: document.querySelector('.form-popup'),
       uploadFormSelect: document.querySelector('.select-upload'),
       uploadFormUserName: document.querySelector('.userInput'),
       uploadFormTitle: document.querySelector('.titleInput'),
       uploadFormPost: document.querySelector('.formUpload'),
       uploadFormUploadButton: document.querySelector('#file'),
//     // searchRes: document.querySelector('.results'),
//     // searchResList: document.querySelector('.results__list'),
       searchResPages: document.querySelector('.results_Photos'),
//     // recipe: document.querySelector('.recipe'),
//     // shopping: document.querySelector('.shopping__list'),
//     // likesMenu: document.querySelector('.likes__field'),
//     // likesList: document.querySelector('.likes__list')
 };

// export const elementStrings = {
//     loader: 'loader'
// };

// export const renderLoader = parent => {
//     // const loader = `
//     //     <div class="${elementStrings.loader}">
//     //         <svg>
//     //             <use href="img/icons.svg#icon-cw"></use>
//     //         </svg>
//     //     </div>
//     // `;
//    // parent.insertAdjacentHTML('afterbegin', loader);
// };

// // export const clearLoader = () => {
// //     const loader = document.querySelector(`.${elementStrings.loader}`);
// //     if (loader) loader.parentElement.removeChild(loader);
// // };
