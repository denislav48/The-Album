 export const elements = {
       searchCategory: document.querySelector('.select'),
       uploadForm: document.querySelector('.form-popup'),
       uploadFormSelect: document.querySelector('.select-upload'),
       uploadFormUserName: document.querySelector('.userInput'),
       uploadFormTitle: document.querySelector('.titleInput'),
       uploadFormPost: document.querySelector('.formUpload'),
       uploadFormUploadFile: document.querySelector('#file'),
       uploadPhotoButton: document.querySelector('.send-photo'),
       popupForm: document.getElementById('.form-popup'),
       formUploadButton: document.querySelector('.formUpload'),
       closeForm: document.querySelector('.cancel'),
       searchResPages: document.querySelector('.results_Photos'),
 };

