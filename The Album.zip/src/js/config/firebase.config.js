export const config = {
    apiKey: "AIzaSyB52-hGKliopcwk9SZeFpfF-fTP9kdgrEk",
    authDomain: "the-album-e3cc7.firebaseapp.com",
    databaseURL: "https://the-album-e3cc7.firebaseio.com",
    projectId: "the-album-e3cc7",
    storageBucket: "the-album-e3cc7.appspot.com",
    messagingSenderId: "854957940443"
  };